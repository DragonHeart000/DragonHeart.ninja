Cave Explorer was made by Riley Shumway as a high school AP Comp Sci final on June 6th, 2017.

There are no planned updates for this game but perhaps if this gets a handful of downloads and I look over it again and it's not rubbish
I will make an update.

Check my portfolio to see if there are any newer versions: https://www.dragonheart.ninja



� 2017